-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: papersdb
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `note_media`
--

LOCK TABLES `note_media` WRITE;
/*!40000 ALTER TABLE `note_media` DISABLE KEYS */;
INSERT INTO `note_media` VALUES (1,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_172911109.jpg',1),(2,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_172911109_01.jpg',1),(3,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_173740721_02.jpg',2),(4,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_192838319.jpg',3),(5,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_172911109_02.jpg',4),(6,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_172911109_03.jpg',4),(7,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_192444212_03.jpg',5),(11,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_173740721_03.jpg',9),(12,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_192444212_01.jpg',9),(13,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_192444212_04.jpg',9),(14,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_200712509.jpg',9),(15,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/5/KakaoTalk_20211118_173740721_01.jpg',11),(17,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_173740721_05.jpg',12),(18,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_200712509_04.jpg',13),(19,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wodud/8/KakaoTalk_20211118_192838319_02.jpg',15),(20,'.PNG','https://papers-bucket.s3.amazonaws.com/diary-file/ssafy_consult/6/white.PNG',17),(21,'.png','https://papers-bucket.s3.amazonaws.com/diary-file/ssafy_coach/7/ssafy.png',19),(22,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/tksgk/9/마카롱.jpg',20),(23,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_192444212.jpg',21),(24,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_173740721_04.jpg',8),(25,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/5/KakaoTalk_20211118_173740721_06.jpg',7),(26,'.jpg','https://papers-bucket.s3.amazonaws.com/diary-file/wlgns/8/KakaoTalk_20211118_172911109_04.jpg',6);
/*!40000 ALTER TABLE `note_media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19 10:32:22
