-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: papersdb
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `note_hashtag`
--

LOCK TABLES `note_hashtag` WRITE;
/*!40000 ALTER TABLE `note_hashtag` DISABLE KEYS */;
INSERT INTO `note_hashtag` VALUES (1,'음식',1),(2,'카페',1),(3,'갬성',2),(4,'멋진 나',2),(5,'애완동물',3),(6,'애완동물',4),(7,'짝사랑',4),(8,'마시쩡',5),(12,'여행스타그램',9),(17,'무지성',11),(20,'갬성',12),(21,'시',12),(22,'판다',13),(23,'사라고',13),(24,'싸게 줄게',13),(25,'어그로',14),(26,'내 생일',15),(27,'선물줘',15),(28,'ssafy',16),(29,'자율프로젝트',16),(30,'별',17),(31,'샘플 일기',18),(32,'하트',19),(33,'아프지말고~',20),(34,'갬성',21),(35,'카페',21),(36,'기분 좋아짐',10),(37,'스웩',10),(38,'갬성',10),(39,'슬퍼용',8),(40,'갬성',8),(41,'농사그램',7),(42,'갬성',7),(43,'여행',6),(44,'멋진 나',6),(45,'갬성',6);
/*!40000 ALTER TABLE `note_hashtag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19 10:32:23
