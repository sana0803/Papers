-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: papersdb
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `sticker`
--

LOCK TABLES `sticker` WRITE;
/*!40000 ALTER TABLE `sticker` DISABLE KEYS */;
INSERT INTO `sticker` VALUES (1,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker1.png',1),(2,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker2.png',1),(3,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker3.png',1),(4,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker4.png',1),(5,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker5.png',1),(6,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/pack1/sticker6.png',1),(7,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle1.png',2),(8,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle2.png',2),(9,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle3.png',2),(10,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle4.png',2),(11,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle5.png',2),(12,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Circle/circle6.png',2),(13,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star1.png',3),(14,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star2.png',3),(15,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star3.png',3),(16,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star4.png',3),(17,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star5.png',3),(18,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/star/star6.png',3),(19,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart1.png',4),(20,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart2.png',4),(21,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart3.png',4),(22,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart4.png',4),(23,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart6.png',4),(24,'https://papers-bucket.s3.ap-northeast-2.amazonaws.com/store/sticker/Heart/heart5.png',4);
/*!40000 ALTER TABLE `sticker` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19 10:32:23
