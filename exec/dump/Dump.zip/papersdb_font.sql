-- MariaDB dump 10.19  Distrib 10.6.4-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: papersdb
-- ------------------------------------------------------
-- Server version	10.6.4-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `font`
--

LOCK TABLES `font` WRITE;
/*!40000 ALTER TABLE `font` DISABLE KEYS */;
INSERT INTO `font` VALUES (1,'기본체',0,'Pretendard Variable'),(2,'코트라 희망체',50,'KOTRAHOPE'),(3,'교보 손글씨체',50,'KyoboHand'),(4,'완도 희망체',50,'WandohopeB'),(5,'카페24 써라운드에어',50,'Cafe24SsurroundAir'),(6,'티웨이하늘체',50,'twaysky'),(7,'Y이드스트릿체',50,'YdestreetB'),(8,'정묵 바위체',50,'SangSangRock'),(9,'서평원 꺾깎체',50,'SLEIGothicTTF'),(10,'어비 깡자체',50,'UhBeeKang-Ja'),(11,'조선일보 명조체',50,'Chosunilbo_myungjo'),(12,'경기천년바탕체',50,'GyeonggiBatang'),(13,'가나 초콜릿체',50,'ghanachoco'),(14,'도스명조체',50,'DOSMyungjo'),(15,'서울한강체',50,'SeoulHangangM'),(16,'어그로체',50,'SBAggroB'),(17,'둥근모꼴',50,'DungGeunMo'),(18,'웰컴체',50,'OTWelcomeRA'),(19,'고운돋음',50,'GowunDodum-Regular'),(20,'망고빙수',50,'SF_IceMango');
/*!40000 ALTER TABLE `font` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19 10:32:21
